My solution is available at: [my GitHub repository](https://github.com/eda-ricercatore/z-estate-2018-stage/tree/master/kpcb-fellows).
